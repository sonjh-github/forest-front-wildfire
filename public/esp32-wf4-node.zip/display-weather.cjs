const { execFileSync } = require('node:child_process');
const { join } = require('node:path');
const { createPixelSender } = require('./wf4/index.cjs');
const { setTimeout: delay } = require('node:timers/promises');

const refreshIntervalMs = 60_000;

function renderLabel(label) {
  const input = Buffer.from(label, 'utf8').toString('base64');
  const output = execFileSync('powershell.exe', [
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', join(__dirname, 'render-weather.ps1'),
  ], { input: input + '\n', encoding: 'utf8', timeout: 10000, windowsHide: true });
  const bitmap = Buffer.from(output.trim(), 'base64');
  return { bitmap, stripWidth: bitmap.length / 32, columns: 7, direction: 'left', step: 1, wrap: true };
}
async function refresh(previousReading) {
  const response = await fetch('http://192.168.79.1/api/weather', {
    signal: AbortSignal.timeout(5000),
  });
  if (!response.ok) throw new Error(`ESP32 HTTP ${response.status}`);
  const { temperature_c, humidity_pct, pressure_hpa, wind_m_s, uptime_ms } = await response.json();
  const values = [temperature_c, humidity_pct, pressure_hpa, wind_m_s];
  if (!values.every(Number.isFinite) || !Number.isSafeInteger(uptime_ms) || uptime_ms < 0) {
    throw new Error('ESP32 has no complete reading yet.');
  }
  const reading = JSON.stringify([uptime_ms, ...values]);
  if (reading === previousReading) {
    console.log(new Date().toLocaleTimeString(), 'No new reading. Display retained.');
    return previousReading;
  }
  console.log(new Date().toLocaleTimeString(), { temperature_c, humidity_pct, pressure_hpa, wind_m_s });
  const label = `${temperature_c.toFixed(1)}°C  ${humidity_pct.toFixed(0)}%  ${pressure_hpa.toFixed(1)}hPa  ${wind_m_s.toFixed(1)}m/s`;
  const scroll = renderLabel(label);
  const sender = createPixelSender({ password: process.env.WF4_DEVICE_PASSWORD ?? '' });
  try {
    const device = await sender.identify();
    if (device.deviceName !== 'WF4_ac276eba005c') {
      throw new Error(`Unexpected WF4 device: ${device.deviceName}`);
    }
    const result = await sender.sendScroll(scroll);
    if (!result.acked) throw new Error('WF4 did not acknowledge the update.');
    console.log('WF4 scroll updated:', result.step, 'px per', result.frameIntervalMs, 'ms.');
    return reading;
  } finally {
    sender.close();
  }
}

async function main() {
  let previousReading;
  while (true) {
    const started = performance.now();
    try {
      previousReading = await refresh(previousReading);
    } catch (error) {
      console.warn(new Date().toLocaleTimeString(), error.message);
    }
    await delay(Math.max(0, refreshIntervalMs - (performance.now() - started)));
  }
}

main();
