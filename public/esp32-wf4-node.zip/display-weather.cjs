const { createPixelSender } = require('./wf4/index.cjs');

// Three-bit rows for a compact 3×5 LED font.
const glyphs = {
  0: '75557', 1: '26227', 2: '71747', 3: '71717', 4: '55711',
  5: '74717', 6: '74757', 7: '71111', 8: '75757', 9: '75717',
  T: '72222', C: '74447', R: '65655', H: '55755', P: '65644',
  A: '25755', W: '55572', M: '57755', S: '74617',
  '%': '51245', '/': '11244', '.': '00002', '-': '00700', ' ': '00000',
};

function draw(pixels, text, panel, top) {
  const left = panel * 64 + Math.floor((64 - (text.length * 8 - 2)) / 2);
  for (const [index, character] of [...text].entries()) {
    for (const [row, bits] of [...glyphs[character]].entries()) {
      for (let column = 0; column < 3; column++) {
        if (!(Number(bits) & (4 >> column))) continue;
        const offset = (top + row * 2) * 256 + left + index * 8 + column * 2;
        pixels.fill(1, offset, offset + 2);
        pixels.fill(1, offset + 256, offset + 258);
      }
    }
  }
}

async function main() {
  const response = await fetch('http://192.168.79.1/api/weather', {
    signal: AbortSignal.timeout(5000),
  });
  if (!response.ok) throw new Error(`ESP32 HTTP ${response.status}`);
  const { temperature_c, humidity_pct, pressure_hpa, wind_m_s } = await response.json();
  const values = [temperature_c, humidity_pct, pressure_hpa, wind_m_s];
  if (!values.every(Number.isFinite)) throw new Error('ESP32 has no complete reading yet.');
  const labels = ['T C', 'RH %', 'P HPA', 'W M/S'];
  const pixels = new Uint8Array(256 * 32);
  values.forEach((value, panel) => {
    draw(pixels, labels[panel], panel, 3);
    draw(pixels, value.toFixed(1), panel, 18);
  });
  const sender = createPixelSender();
  try {
    const device = await sender.identify();
    if (device.deviceName !== 'WF4_441bf6eef410') {
      throw new Error(`Unexpected WF4 device: ${device.deviceName}`);
    }
    const result = await sender.sendPixels({ pixels });
    console.log({ temperature_c, humidity_pct, pressure_hpa, wind_m_s, ...result });
  } finally {
    sender.close();
  }
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
