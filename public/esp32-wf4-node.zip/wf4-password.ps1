param([switch]$Reset)

$ErrorActionPreference = 'Stop'
$directory = Join-Path $env:LOCALAPPDATA 'Esp32Weather'
$file = Join-Path $directory 'WF4_ac276eba005c.key'
if ($Reset -or -not (Test-Path -LiteralPath $file)) {
    [Console]::Error.Write('WF4 5C device password: ')
    $password = [Security.SecureString]::new()
    while ($true) {
        $key = [Console]::ReadKey($true)
        if ($key.Key -eq [ConsoleKey]::Enter) { break }
        if ($key.Key -eq [ConsoleKey]::Backspace) {
            if ($password.Length -gt 0) { $password.RemoveAt($password.Length - 1) }
        } elseif (-not [char]::IsControl($key.KeyChar)) {
            $password.AppendChar($key.KeyChar)
        }
    }
    [Console]::Error.WriteLine()
    if ($password.Length -eq 0) { throw 'A device password is required.' }
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    ConvertFrom-SecureString $password | Set-Content -LiteralPath $file -Encoding ASCII
} else {
    $password = (Get-Content -LiteralPath $file -Raw).Trim() | ConvertTo-SecureString
}
$pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
try {
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    [Console]::WriteLine([Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer))
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    $password.Dispose()
}
