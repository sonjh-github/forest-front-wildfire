Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'
$label = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([Console]::ReadLine()))
$fonts = [Drawing.Text.PrivateFontCollection]::new()
$fonts.AddFontFile((Join-Path $PSScriptRoot 'fonts/NanumSquareR.ttf'))
$canvas = [Drawing.Bitmap]::new(255, 32)
$graphics = [Drawing.Graphics]::FromImage($canvas)
$format = [Drawing.StringFormat]::GenericTypographic
$format.Alignment = [Drawing.StringAlignment]::Near
$format.LineAlignment = [Drawing.StringAlignment]::Center
$graphics.TextRenderingHint = [Drawing.Text.TextRenderingHint]::SingleBitPerPixelGridFit

try {
    for ($size = 22; $size -ge 10; $size--) {
        $font = [Drawing.Font]::new($fonts.Families[0], $size, [Drawing.FontStyle]::Regular, [Drawing.GraphicsUnit]::Pixel)
        $width = [int][Math]::Ceiling($graphics.MeasureString($label, $font, 4096, $format).Width) + 2
        if ($width -le 255) { break }
        $font.Dispose()
        $font = $null
    }
    if ($null -eq $font) { throw 'Weather text exceeds 255 pixels.' }
    $graphics.Clear([Drawing.Color]::Black)
    $bounds = [Drawing.RectangleF]::new(1, 0, $width - 1, 32)
    $graphics.DrawString($label, $font, [Drawing.Brushes]::White, $bounds, $format)
    $pixels = [byte[]]::new($width * 32)
    for ($y = 0; $y -lt 32; $y++) {
        for ($x = 0; $x -lt $width; $x++) {
            if ($canvas.GetPixel($x, $y).R -ge 128) { $pixels[$y * $width + $x] = 1 }
        }
    }
    [Console]::WriteLine([Convert]::ToBase64String($pixels))
} finally {
    if ($null -ne $font) { $font.Dispose() }
    $format.Dispose()
    $graphics.Dispose()
    $canvas.Dispose()
    $fonts.Dispose()
}
